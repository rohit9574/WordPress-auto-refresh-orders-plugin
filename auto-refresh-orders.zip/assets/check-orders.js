(function ($) {
    let lastOrderId = 0;

    function checkNewOrders() {
        $.ajax({
            url: aroAjax.ajaxUrl,
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'aro_check_orders',
                nonce: aroAjax.nonce,
            },
            success: function (response) {
                if (response.success && response.data.latestOrderId) {
                    if (lastOrderId === 0) {
                        lastOrderId = response.data.latestOrderId;
                    } else if (lastOrderId < response.data.latestOrderId) {
                        location.reload();
                    }
                }
            },
        });
    }

    setInterval(checkNewOrders, 10000); // Check every 10 seconds.
})(jQuery);
