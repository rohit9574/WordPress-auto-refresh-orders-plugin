(function ($) {
    $(document).ready(function () {
        if (typeof aroSettings !== "undefined" && aroSettings.refreshInterval) {
            setTimeout(function () {
                location.reload();
            }, aroSettings.refreshInterval * 1000);
        }
    });
})(jQuery);
