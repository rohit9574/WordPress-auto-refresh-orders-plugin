<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Add settings page.
function aro_register_settings() {
    add_settings_section(
        'aro_settings_section',
        __( 'Auto Refresh Orders Settings', 'auto-refresh-orders' ),
        null,
        'general'
    );

    // Refresh type.
    add_settings_field(
        'aro_refresh_type',
        __( 'Refresh Type', 'auto-refresh-orders' ),
        'aro_refresh_type_field',
        'general',
        'aro_settings_section'
    );

    register_setting( 'general', 'aro_refresh_type', array(
        'type' => 'string',
        'description' => __( 'Choose the refresh method.', 'auto-refresh-orders' ),
        'default' => 'time',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    // Refresh interval.
    add_settings_field(
        'aro_refresh_interval',
        __( 'Refresh Interval', 'auto-refresh-orders' ),
        'aro_refresh_interval_field',
        'general',
        'aro_settings_section'
    );

    register_setting( 'general', 'aro_refresh_interval', array(
        'type' => 'integer',
        'description' => __( 'Time interval for auto-refreshing the orders page.', 'auto-refresh-orders' ),
        'default' => 60,
        'sanitize_callback' => 'absint',
    ));

    // Refresh interval unit.
    add_settings_field(
        'aro_refresh_time_unit',
        __( 'Time Unit', 'auto-refresh-orders' ),
        'aro_refresh_time_unit_field',
        'general',
        'aro_settings_section'
    );

    register_setting( 'general', 'aro_refresh_time_unit', array(
        'type' => 'string',
        'description' => __( 'Select seconds or minutes.', 'auto-refresh-orders' ),
        'default' => 'seconds',
        'sanitize_callback' => 'sanitize_text_field',
    ));
}
add_action( 'admin_init', 'aro_register_settings' );

// Render the refresh type field.
function aro_refresh_type_field() {
    $value = get_option( 'aro_refresh_type', 'time' );
    ?>
    <select id="aro_refresh_type" name="aro_refresh_type">
        <option value="time" <?php selected( $value, 'time' ); ?>><?php esc_html_e( 'Refresh After Time Interval', 'auto-refresh-orders' ); ?></option>
        <option value="new_order" <?php selected( $value, 'new_order' ); ?>><?php esc_html_e( 'Refresh On New Order', 'auto-refresh-orders' ); ?></option>
    </select>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const refreshType = document.getElementById('aro_refresh_type');
            const intervalField = document.getElementById('aro_refresh_interval').closest('tr');
            const timeUnitField = document.getElementById('aro_refresh_time_unit').closest('tr');

            function toggleFields() {
                if (refreshType.value === 'time') {
                    intervalField.style.display = '';
                    timeUnitField.style.display = '';
                } else {
                    intervalField.style.display = 'none';
                    timeUnitField.style.display = 'none';
                }
            }

            refreshType.addEventListener('change', toggleFields);
            toggleFields(); // Initialize on load.
        });
    </script>
    <?php
}

// Render the refresh interval field.
function aro_refresh_interval_field() {
    $value = get_option( 'aro_refresh_interval', 60 );
    echo '<input type="number" id="aro_refresh_interval" name="aro_refresh_interval" value="' . esc_attr( $value ) . '" class="small-text" min="1" />';
    echo '<p class="description">' . esc_html__( 'Enter the time interval (minimum 1).', 'auto-refresh-orders' ) . '</p>';
}

// Render the time unit field.
function aro_refresh_time_unit_field() {
    $value = get_option( 'aro_refresh_time_unit', 'seconds' );
    ?>
    <select id="aro_refresh_time_unit" name="aro_refresh_time_unit">
        <option value="seconds" <?php selected( $value, 'seconds' ); ?>><?php esc_html_e( 'Seconds', 'auto-refresh-orders' ); ?></option>
        <option value="minutes" <?php selected( $value, 'minutes' ); ?>><?php esc_html_e( 'Minutes', 'auto-refresh-orders' ); ?></option>
    </select>
    <?php
}
