<?php
/**
 * Plugin Name: Auto Refresh Orders
 * Description: A WooCommerce plugin to automatically refresh the orders page based on time interval or new order placement.
 * Version: 1.0.0
 * Author: Rohit Lohar
 * License: GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: auto-refresh-orders
 * Requires at least: 5.0
 * Tested up to: 6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Define constants.
define( 'ARO_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'ARO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

// Include settings page.
require_once ARO_PLUGIN_DIR . 'includes/settings.php';

// Enqueue scripts.
function aro_enqueue_scripts() {
    if ( is_admin() && isset( $_GET['page'] ) && $_GET['page'] === 'wc-orders' ) {
        $refresh_type = get_option( 'aro_refresh_type', 'time' );
        $refresh_interval = get_option( 'aro_refresh_interval', 60 );
        $time_unit = get_option( 'aro_refresh_time_unit', 'seconds' );

        // Convert minutes to seconds if necessary.
        if ( $time_unit === 'minutes' ) {
            $refresh_interval *= 60;
        }

        if ( $refresh_type === 'time' ) {
            wp_enqueue_script( 'aro-auto-refresh', ARO_PLUGIN_URL . 'assets/auto-refresh.js', array( 'jquery' ), '1.2.0', true );
            wp_localize_script( 'aro-auto-refresh', 'aroSettings', array(
                'refreshInterval' => absint( $refresh_interval ),
            ));
        } elseif ( $refresh_type === 'new_order' ) {
            wp_enqueue_script( 'aro-check-orders', ARO_PLUGIN_URL . 'assets/check-orders.js', array( 'jquery' ), '1.2.0', true );
            wp_localize_script( 'aro-check-orders', 'aroAjax', array(
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'nonce'   => wp_create_nonce( 'aro_check_orders' ),
            ));
        }
    }
}
add_action( 'admin_enqueue_scripts', 'aro_enqueue_scripts' );

// Handle AJAX to check for new orders.
function aro_check_new_orders() {
    check_ajax_referer( 'aro_check_orders', 'nonce' );

    $latest_order_id = wc_get_orders( array(
        'limit' => 1,
        'orderby' => 'date',
        'order' => 'DESC',
        'return' => 'ids',
    ) );

    wp_send_json_success( array( 'latestOrderId' => $latest_order_id ? $latest_order_id[0] : 0 ) );
}
add_action( 'wp_ajax_aro_check_orders', 'aro_check_new_orders' );
