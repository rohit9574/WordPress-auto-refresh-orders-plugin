=== Auto Refresh Orders ===
Contributors: rohit9574
Tags: woocommerce, refresh, orders, auto refresh, ajax
Requires at least: 5.0
Tested up to: 6.7.1
Stable tag: 1.0.0
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
The Auto Refresh Orders plugin automatically refreshes the WooCommerce orders page either after a specified time interval or when a new order is placed.

== Installation ==
1. Upload the plugin zip file to the WordPress dashboard.
2. Activate the plugin.
3. Configure the settings under Settings > General.

== Changelog ==
= 1.0.0 =
* Initial release of the plugin.
